#define TAILLE 50

#define  NB_MAX_PRODUITS 1000


typedef struct 
{
unsigned int reference;
char libelle[TAILLE];
float prixU;
} T_Produit;

typedef struct {
    char client[30]; // Nom du client
    int refProduit[35]; // Référence du produit
    int nbMemeProduit[35]; // Nombre de fois où il y a le même produit
    int nbDiffProduit; // Nombre de produits différents
} T_Commande;

typedef T_Produit T_TableauDeProduits[ NB_MAX_PRODUITS];

int lireCommande(char *nomCommande, char *NNNN);
void alertes(int ref);
int suppstock(int ref, int nbr);
int lireCommande2(char *nomCommande, char *NNNN);
void convertirNenChaine4(int N,char *N4);
int lireProchaineCommande();